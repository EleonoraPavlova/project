<template>
	<div class="p-3">
		<h5 class="m-0"><slot /></h5>
	</div>
</template>

<script>
export default {
	name: "DescriptionVue",
	data() {
		return {};
	},
};
</script>

<style>
</style>