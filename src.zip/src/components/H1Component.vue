<template>
	<h1>
		<slot />
	</h1>
</template>

<script>
export default {
	name: "H1Component",
};
</script>

<style>
</style>