<template>
	<div class="form-control">
		<DescriptionVue>{{ article.title }} </DescriptionVue>
		<div class="">
			<p>{{ article.summary }}</p>
			<p>{{ article.country }}</p>
			<p>{{ article.author }}</p>
			<p>{{ article.published_date }}</p>
		</div>
	</div>
</template>

<script>
import DescriptionVue from "../components/DescriptionVue.vue";

export default {
	name: "NewsBox",
	components: {
		DescriptionVue,
	},
	props: {
		article: {
			type: Object,
			default: null,
		},
	},
	data() {
		return {};
	},
};
</script>

<style>
</style>