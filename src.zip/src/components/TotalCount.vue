<template>
	<h4 class="m-4"><slot /></h4>
</template>

<script>
export default {
	name: "TotalCounter",
};
</script>

<style>
</style>